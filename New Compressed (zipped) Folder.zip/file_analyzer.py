from __future__ import annotations

import ast
from pathlib import Path
from typing import Any, Dict, List

import streamlit as st


def analyze_python_file(file_text: str) -> Dict[str, Any]:
    lines = file_text.splitlines()

    results: Dict[str, Any] = {
        "line_count": len(lines),
        "char_count": len(file_text),
        "import_count": 0,
        "function_count": 0,
        "class_count": 0,
        "todo_count": 0,
        "issues": [],
        "imports": [],
        "functions": [],
        "classes": [],
    }

    for raw_line in lines:
        stripped = raw_line.strip()

        if stripped.startswith("import ") or stripped.startswith("from "):
            results["import_count"] += 1
            results["imports"].append(stripped)

        if "TODO" in raw_line or "FIXME" in raw_line:
            results["todo_count"] += 1

    try:
        tree = ast.parse(file_text)
    except SyntaxError as exc:
        results["issues"].append(
            f"SyntaxError on line {exc.lineno}: {exc.msg}"
        )
        return results

    for node in ast.walk(tree):
        if isinstance(node, ast.FunctionDef):
            results["function_count"] += 1
            results["functions"].append(node.name)

        elif isinstance(node, ast.AsyncFunctionDef):
            results["function_count"] += 1
            results["functions"].append(node.name)

        elif isinstance(node, ast.ClassDef):
            results["class_count"] += 1
            results["classes"].append(node.name)

    if results["line_count"] > 300:
        results["issues"].append("File is getting large. Consider splitting it into smaller modules.")

    if results["todo_count"] > 0:
        results["issues"].append(f"Found {results['todo_count']} TODO/FIXME note(s).")

    if results["function_count"] == 0:
        results["issues"].append("No functions found.")

    return results


def analyze_python_path(file_path: str) -> Dict[str, Any]:
    path = Path(file_path)

    if not path.exists():
        return {
            "error": f"File not found: {file_path}"
        }

    if not path.is_file():
        return {
            "error": f"Not a file: {file_path}"
        }

    try:
        text = path.read_text(encoding="utf-8")
    except UnicodeDecodeError:
        text = path.read_text(encoding="latin-1")

    return analyze_python_file(text)


def summarize_analysis(analysis: Dict[str, Any]) -> List[str]:
    if "error" in analysis:
        return [analysis["error"]]

    summary = [
        f"Lines: {analysis.get('line_count', 0)}",
        f"Characters: {analysis.get('char_count', 0)}",
        f"Imports: {analysis.get('import_count', 0)}",
        f"Functions: {analysis.get('function_count', 0)}",
        f"Classes: {analysis.get('class_count', 0)}",
        f"TODO/FIXME notes: {analysis.get('todo_count', 0)}",
    ]

    return summary


def render(progress_data=None):
    _ = progress_data  # keeps signature compatible with app.py
    st.subheader("File Analyzer Mode")

    uploaded_file = st.file_uploader(
        "Upload a Python file",
        type=["py"],
        key="file_analyzer_uploader",
    )

    if not uploaded_file:
        st.info("Upload a .py file to analyze it.")
        return

    try:
        file_text = uploaded_file.read().decode("utf-8")
    except UnicodeDecodeError:
        file_text = uploaded_file.read().decode("latin-1")

    analysis = analyze_python_file(file_text)

    if "error" in analysis:
        st.error(analysis["error"])
        return

    col1, col2, col3 = st.columns(3)
    with col1:
        st.metric("Lines", analysis["line_count"])
        st.metric("Imports", analysis["import_count"])
    with col2:
        st.metric("Functions", analysis["function_count"])
        st.metric("Classes", analysis["class_count"])
    with col3:
        st.metric("Characters", analysis["char_count"])
        st.metric("TODO/FIXME", analysis["todo_count"])

    st.markdown("### Summary")
    for item in summarize_analysis(analysis):
        st.write(f"- {item}")

    if analysis["imports"]:
        st.markdown("### Imports")
        for item in analysis["imports"]:
            st.code(item, language="python")

    if analysis["functions"]:
        st.markdown("### Functions")
        st.write(", ".join(analysis["functions"]))

    if analysis["classes"]:
        st.markdown("### Classes")
        st.write(", ".join(analysis["classes"]))

    if analysis["issues"]:
        st.markdown("### Issues")
        for issue in analysis["issues"]:
            st.warning(issue)
    else:
        st.success("No major issues found.")

    with st.expander("Show file contents"):
        st.code(file_text, language="python")