import streamlit as st


def auth_is_configured():
    try:
        auth_section = st.secrets.get("auth", {})
        return bool(
            auth_section.get("client_id")
            and auth_section.get("client_secret")
            and auth_section.get("redirect_uri")
        )
    except KeyError:
        return False
    except AttributeError:
        return False


def init_auth():
    return None


def auth_sidebar():
    st.markdown("### Account")

    if not auth_is_configured():
        st.info("Authentication not configured yet.")
        st.caption("Guest mode is active.")
        return

    try:
        if getattr(st.user, "is_logged_in", False):
            name = getattr(st.user, "name", "User")
            email = getattr(st.user, "email", "")

            st.success(f"Signed in as {name}")
            if email:
                st.caption(email)

            if st.button("Log out", use_container_width=True):
                st.logout()
        else:
            st.info("Guest mode (progress saved locally).")
            if st.button("Sign in with Google", use_container_width=True):
                st.login()
    except AttributeError:
        st.info("Authentication UI temporarily unavailable.")
    except RuntimeError:
        st.info("Authentication UI temporarily unavailable.")


def account_badge():
    try:
        if getattr(st.user, "is_logged_in", False):
            email = getattr(st.user, "email", "")
            st.caption(f"☁️ Synced account: {email}")
        else:
            st.caption("💾 Local guest progress")
    except AttributeError:
        st.caption("💾 Local guest progress")
    except RuntimeError:
        st.caption("💾 Local guest progress")