from __future__ import annotations

import ast
import contextlib
import io
import os
import traceback
from typing import Any, Dict

import requests
import streamlit as st


def validate_python_code(code: str) -> tuple[bool, str]:
    try:
        ast.parse(code)
        return True, "Syntax looks valid."
    except SyntaxError as error:
        return False, f"Syntax error on line {error.lineno}: {error.msg}"


def run_python_code_local(code: str) -> Dict[str, Any]:
    stdout_buffer = io.StringIO()
    execution_globals = {"__name__": "__main__"}

    try:
        with contextlib.redirect_stdout(stdout_buffer):
            exec(code, execution_globals)

        return {
            "success": True,
            "stdout": stdout_buffer.getvalue(),
            "stderr": "",
            "error_type": None,
            "runner": "local",
        }
    except Exception as error:
        return {
            "success": False,
            "stdout": stdout_buffer.getvalue(),
            "stderr": traceback.format_exc(),
            "error_type": type(error).__name__,
            "runner": "local",
        }


def run_python_code_remote(code: str) -> Dict[str, Any]:
    judge0_url = os.getenv("JUDGE0_API_URL")
    judge0_key = os.getenv("JUDGE0_API_KEY")

    if not judge0_url:
        raise RuntimeError("Remote runner is not configured.")

    headers = {"Content-Type": "application/json"}

    if judge0_key:
        headers["X-Auth-Token"] = judge0_key

    try:
        judge0_url = st.secrets.get("JUDGE0_API_URL")
        judge0_key = st.secrets.get("JUDGE0_API_KEY")
    except (AttributeError, KeyError):
        judge0_url = os.getenv("JUDGE0_API_URL")
        judge0_key = os.getenv("JUDGE0_API_KEY")

    if not judge0_url:
        raise RuntimeError("Remote runner is not configured.")

    headers = {"Content-Type": "application/json"}
    if judge0_key:
        headers["X-Auth-Token"] = judge0_key

    response = requests.post(
        judge0_url,
        headers=headers,
        json={
            "language_id": 71,
            "source_code": code,
        },
        timeout=20,
    )
    response.raise_for_status()
    data = response.json()

    stdout_value = data.get("stdout") or ""
    stderr_value = data.get("stderr") or data.get("compile_output") or ""
    success = not bool(stderr_value)

    return {
        "success": success,
        "stdout": stdout_value,
        "stderr": stderr_value,
        "error_type": None if success else "ExecutionError",
        "runner": "remote",
    }


def run_user_code(code: str) -> Dict[str, Any]:
    valid, message = validate_python_code(code)

    if not valid:
        return {
            "success": False,
            "stdout": "",
            "stderr": message,
            "error_type": "SyntaxError",
            "runner": "validation",
        }

    prefer_remote = st.session_state.get("prefer_remote_runner", False)

    if prefer_remote:
        try:
            return run_python_code_remote(code)
        except Exception as error:
            return {
                "success": False,
                "stdout": "",
                "stderr": (
                    "Remote sandbox is not ready yet.\n\n"
                    f"Details: {error}\n\n"
                    "The app fell back conceptually, but full production sandboxing "
                    "requires a configured external runner such as Judge0 or Docker."
                ),
                "error_type": "RemoteRunnerError",
                "runner": "remote",
            }

    return run_python_code_local(code)


def ensure_run_state() -> None:
    if "run_test_code" not in st.session_state:
        st.session_state["run_test_code"] = (
            'name = "Pylot"\n'
            'print(f"Hello, {name}!")'
        )

    if "run_test_result" not in st.session_state:
        st.session_state["run_test_result"] = None

    if "prefer_remote_runner" not in st.session_state:
        st.session_state["prefer_remote_runner"] = False


def render_examples() -> None:
    with st.expander("Example snippets", expanded=False):
        st.code(
            'name = "Pylot"\nprint(f"Hello, {name}!")',
            language="python",
        )
        st.caption("Simple output example")

        st.code(
            "numbers = [1, 2, 3]\nfor number in numbers:\n    print(number * 2)",
            language="python",
        )
        st.caption("Loop example")

        st.code(
            "def add(a, b):\n    return a + b\n\nprint(add(2, 3))",
            language="python",
        )
        st.caption("Function example")


def render_result(result: Dict[str, Any]) -> None:
    st.markdown("### Result")
    st.caption(f"Runner used: {result.get('runner', 'unknown')}")

    if result["success"]:
        st.success("Code ran successfully.")
    else:
        error_type = result.get("error_type") or "Error"
        st.error(f"Code failed with {error_type}.")

    col1, col2 = st.columns(2)

    with col1:
        st.markdown("#### Output")
        stdout_value = result.get("stdout", "")
        if stdout_value.strip():
            st.code(stdout_value, language="text")
        else:
            st.caption("No stdout output.")

    with col2:
        st.markdown("#### Errors")
        stderr_value = result.get("stderr", "")
        if stderr_value.strip():
            st.code(stderr_value, language="text")
        else:
            st.caption("No errors.")


def set_run_result(result: Dict[str, Any]) -> None:
    st.session_state["run_test_result"] = result
    st.rerun()


def clear_run_state() -> None:
    st.session_state["run_test_code"] = ""
    st.session_state["run_test_result"] = None
    st.rerun()


def render(progress_data: Dict[str, Any]) -> None:
    _ = progress_data

    ensure_run_state()

    st.markdown(
        """
        <div style="
            padding: 1rem;
            border-radius: 18px;
            background: rgb(248, 250, 252);
            border: 1px solid rgba(148, 163, 184, 0.18);
            margin-bottom: 1rem;
        ">
            <h3 style="margin:0;">▶️ Run/Test Mode</h3>
            <p style="margin:0.35rem 0 0 0; color: rgb(71, 85, 105);">
                Validate Python syntax, run code, and inspect output or errors directly in the site.
            </p>
        </div>
        """,
        unsafe_allow_html=True,
    )

    st.info(
        "Local runner works now. Production-safe browser sandboxing needs an external isolated runner. "
        "This page is already wired to support a remote runner later."
    )

    render_examples()

    st.toggle(
        "Use remote sandbox runner when configured",
        key="prefer_remote_runner",
    )

    code = st.text_area(
        "Python code",
        value=st.session_state.get("run_test_code", ""),
        height=320,
        key="run_test_code_editor",
    )
    st.session_state["run_test_code"] = code

    col1, col2, col3 = st.columns(3)

    with col1:
        if st.button("Check Syntax", use_container_width=True):
            valid, message = validate_python_code(code)
            set_run_result(
                {
                    "success": valid,
                    "stdout": "",
                    "stderr": "" if valid else message,
                    "error_type": None if valid else "SyntaxError",
                    "runner": "validation",
                }
            )

    with col2:
        if st.button("Run Code", use_container_width=True):
            set_run_result(run_user_code(code))

    with col3:
        if st.button("Clear", use_container_width=True):
            clear_run_state()

    result = st.session_state.get("run_test_result")
    if result:
        render_result(result)