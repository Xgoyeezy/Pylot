import os

import streamlit as st
from openai import OpenAI

_client = None


def get_openai_api_key() -> str | None:
    """
    Gets the OpenAI API key from Streamlit secrets or environment variables.
    """
    try:
        return st.secrets.get("OPENAI_API_KEY")
    except AttributeError:
        return os.getenv("OPENAI_API_KEY")


def get_openai_client() -> OpenAI | None:
    """
    Returns a cached OpenAI client instance.
    """
    global _client

    if _client is not None:
        return _client

    api_key = get_openai_api_key()

    if not api_key:
        return None

    _client = OpenAI(api_key=api_key)
    return _client