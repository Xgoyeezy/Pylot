from __future__ import annotations

from typing import Any, Dict

import streamlit as st

from core.live_ai import get_live_ai_response


WELCOME_MESSAGE = (
    "Hey — I’m your Python tutor inside Pylot.\n\n"
    "Ask me anything about Python:\n"
    "- concepts\n"
    "- debugging\n"
    "- reviewing your code\n"
    "- building projects\n"
    "- preparing exercises\n\n"
    "You do not need to choose a topic first. Just type naturally."
)


def ensure_ai_state() -> None:
    if "ai_chat_history" not in st.session_state:
        st.session_state["ai_chat_history"] = [
            {
                "role": "assistant",
                "content": WELCOME_MESSAGE,
            }
        ]

    if "ai_input_prefill" not in st.session_state:
        st.session_state["ai_input_prefill"] = ""

    if "ai_last_system_prompt" not in st.session_state:
        st.session_state["ai_last_system_prompt"] = ""

    if "ai_last_user_prompt" not in st.session_state:
        st.session_state["ai_last_user_prompt"] = ""


def reset_ai_chat() -> None:
    st.session_state["ai_chat_history"] = [
        {
            "role": "assistant",
            "content": WELCOME_MESSAGE,
        }
    ]
    st.session_state["ai_input_prefill"] = ""
    st.session_state["ai_last_system_prompt"] = ""
    st.session_state["ai_last_user_prompt"] = ""


def add_chat_message(role: str, content: str) -> None:
    st.session_state["ai_chat_history"].append(
        {
            "role": role,
            "content": content,
        }
    )


def detect_role_from_prompt(prompt: str) -> str:
    lowered = prompt.lower()

    debug_keywords = [
        "error",
        "traceback",
        "bug",
        "fix this",
        "why does this fail",
        "debug",
        "exception",
    ]

    review_keywords = [
        "review my code",
        "code review",
        "is this good",
        "improve this code",
        "make this more pythonic",
        "refactor",
    ]

    if any(keyword in lowered for keyword in debug_keywords):
        return "debugger"

    if any(keyword in lowered for keyword in review_keywords):
        return "reviewer"

    return "tutor"


def render_quick_actions() -> None:
    st.markdown("### Quick Starts")

    col1, col2, col3, col4 = st.columns(4)

    with col1:
        if st.button("Explain loops", use_container_width=True):
            st.session_state["ai_input_prefill"] = "Explain Python loops simply with examples."

    with col2:
        if st.button("Debug code", use_container_width=True):
            st.session_state["ai_input_prefill"] = (
                "Help me debug this Python code:\n\n```python\n# paste code here\n```"
            )

    with col3:
        if st.button("Practice exercise", use_container_width=True):
            st.session_state["ai_input_prefill"] = (
                "Give me a Python practice exercise at my level, but do not show the solution yet."
            )

    with col4:
        if st.button("Project idea", use_container_width=True):
            st.session_state["ai_input_prefill"] = (
                "Give me a beginner-friendly Python project idea and a step-by-step build plan."
            )


def render_chat_history() -> None:
    for message in st.session_state["ai_chat_history"]:
        with st.chat_message(message["role"]):
            st.markdown(message["content"])


def build_context_payload(progress_data: Dict[str, Any]) -> Dict[str, Any]:
    return {
        "completed_lessons": progress_data.get("completed_lessons", []),
        "completed_projects": progress_data.get("completed_projects", []),
        "review_passed": progress_data.get("review_passed", {}),
        "weak_topics": progress_data.get("weak_topics", {}),
    }


def render_debug_panel() -> None:
    with st.expander("AI Debug Panel", expanded=False):
        st.caption("Useful while wiring prompts and memory.")
        st.markdown("**Last System Prompt**")
        st.code(st.session_state.get("ai_last_system_prompt", ""), language="text")

        st.markdown("**Last User Prompt**")
        st.code(st.session_state.get("ai_last_user_prompt", ""), language="text")


def render(progress_data: Dict[str, Any]) -> None:
    ensure_ai_state()

    st.markdown(
        """
        <div style="
            padding: 1rem 1rem 0.9rem 1rem;
            border-radius: 18px;
            background: rgb(248, 250, 252);
            border: 1px solid rgba(148, 163, 184, 0.18);
            margin-bottom: 1rem;
        ">
            <h3 style="margin:0;">🤖 AI Tutor</h3>
            <p style="margin:0.35rem 0 0 0; color:#475569;">
                Chat naturally about Python. Ask questions, paste code, debug errors,
                get explanations, or request practice.
            </p>
        </div>
        """,
        unsafe_allow_html=True,
    )

    top_left, top_right = st.columns([5, 1])

    with top_left:
        render_quick_actions()

    with top_right:
        st.markdown("### ")
        if st.button("Clear Chat", use_container_width=True):
            reset_ai_chat()
            st.rerun()

    render_chat_history()

    prefill = st.session_state.get("ai_input_prefill", "")
    if prefill:
        st.text_area(
            "Prepared prompt",
            value=prefill,
            height=120,
            key="ai_prefill_preview",
            disabled=True,
        )

    user_prompt = st.chat_input("Ask anything about Python...")

    if not user_prompt and prefill:
        manual_send_col1, manual_send_col2 = st.columns([1, 5])
        _ = manual_send_col2

        with manual_send_col1:
            send_prefill = st.button("Send", use_container_width=True)

        if send_prefill:
            user_prompt = prefill
            st.session_state["ai_input_prefill"] = ""

    if user_prompt:
        add_chat_message("user", user_prompt)

        with st.chat_message("user"):
            st.markdown(user_prompt)

        role = detect_role_from_prompt(user_prompt)
        lesson_context = build_context_payload(progress_data)

        with st.chat_message("assistant"):
            reply = ""
            thinking_box = st.empty()
            thinking_box.info("Thinking...")

            try:
                system_prompt, built_user_prompt, reply = get_live_ai_response(
                    role=role,
                    question=user_prompt,
                    code="",
                    error_text="",
                    lesson=lesson_context,
                    weak_topics=progress_data.get("weak_topics", {}),
                    model="gpt-4o-mini",
                    use_shared_memory=True,
                )

                st.session_state["ai_last_system_prompt"] = system_prompt
                st.session_state["ai_last_user_prompt"] = built_user_prompt

                if not reply.strip():
                    reply = (
                        "I did not get a complete response back. Try asking again, "
                        "or make the question a little more specific."
                    )

                thinking_box.empty()
                st.markdown(reply)

            except RuntimeError as error:
                reply = (
                    "AI Mode is not configured yet.\n\n"
                    f"Details: `{error}`\n\n"
                    "Make sure your OpenAI API key is set in `.streamlit/secrets.toml` "
                    "or as an environment variable."
                )
                thinking_box.empty()
                st.error(reply)

            except Exception as error:
                reply = f"AI Mode hit an error:\n\n`{error}`"
                thinking_box.empty()
                st.error(reply)

        add_chat_message("assistant", reply)

    render_debug_panel()