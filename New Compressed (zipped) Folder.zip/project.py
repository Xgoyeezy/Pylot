from __future__ import annotations

from typing import Any, Dict, List, Optional, Sequence, Callable

import streamlit as st

from progress import (
    has_passed_project_review,
    is_project_complete,
    mark_project_complete,
)

ProjectDict = Dict[str, Any]


# -------------------------
# PROJECT DATA
# -------------------------

PROJECTS: List[ProjectDict] = [
    {
        "id": "project-1",
        "title": "Greeting App",
        "level": "Beginner",
        "duration": "20 min",
        "summary": "Build a program that greets the user.",
        "goal": "Practice variables, input, and printing.",
        "requirements": [
            "Ask the user for their name",
            "Store the name in a variable",
            "Print a greeting",
        ],
        "starter_code": 'name = input("What is your name? ")\n',
        "example_output": "Hello Marcus!",
    },
    {
        "id": "project-2",
        "title": "Number Checker",
        "level": "Beginner",
        "duration": "25 min",
        "summary": "Check if a number is positive, negative, or zero.",
        "goal": "Practice conditionals.",
        "requirements": [
            "Ask for a number",
            "Convert to int",
            "Use if/elif/else",
        ],
        "starter_code": 'num = int(input("Enter number: "))\n',
        "example_output": "Positive",
    },
]


# -------------------------
# GENERIC UI HELPERS
# -------------------------

def rerun(**updates: Any) -> None:
    for k, v in updates.items():
        st.session_state[k] = v
    st.rerun()


def button(label: str, key: str, action: Callable[[], None], disabled: bool = False) -> None:
    if st.button(label, key=key, use_container_width=True, disabled=disabled):
        action()


def metric_row(metrics: Sequence[tuple[str, Any]]) -> None:
    cols = st.columns(len(metrics))
    for col, (label, value) in zip(cols, metrics):
        with col:
            st.metric(label, value)


def card(title: str, body: str) -> None:
    st.markdown(
        f"""
        <div style="
            border:1px solid rgba(148,163,184,0.20);
            border-radius:14px;
            padding:1rem;
            margin-bottom:1rem;
            background:white;
        ">
        <h4>{title}</h4>
        <p style="color:rgb(71,85,105);">{body}</p>
        </div>
        """,
        unsafe_allow_html=True,
    )


# -------------------------
# PROJECT STATE
# -------------------------

def get_project(pid: str) -> Optional[ProjectDict]:
    for p in PROJECTS:
        if p["id"] == pid:
            return p
    return None


def project_status(pid: str) -> tuple[bool, bool]:
    return (
        is_project_complete(pid),
        has_passed_project_review(pid),
    )


def project_summary() -> Dict[str, int]:
    completed = 0
    review = 0

    for p in PROJECTS:
        c, r = project_status(p["id"])
        if c:
            completed += 1
        if r:
            review += 1

    return {
        "total": len(PROJECTS),
        "completed": completed,
        "review": review,
    }


# -------------------------
# PROJECT LIST VIEW
# -------------------------

def render_catalog() -> None:
    st.subheader("Projects")

    cols = st.columns(2)

    for i, project in enumerate(PROJECTS):
        with cols[i % 2]:

            card(project["title"], project["summary"])

            button(
                f"Open {project['title']}",
                f"open_{project['id']}",
                lambda p=project["id"]: rerun(selected_project_id=p),
            )


# -------------------------
# PROJECT DETAIL VIEW
# -------------------------

def render_project(project: ProjectDict) -> None:

    pid = project["id"]

    completed, review_passed = project_status(pid)

    st.title(project["title"])

    metric_row([
        ("Level", project["level"]),
        ("Duration", project["duration"]),
        ("Status", "Complete" if completed else "Active"),
    ])

    st.markdown("### Goal")
    st.write(project["goal"])

    st.markdown("### Requirements")
    for r in project["requirements"]:
        st.write(f"- {r}")

    st.markdown("### Example Output")
    st.code(project["example_output"])

    code_key = f"project_code_{pid}"
    code = st.session_state.get(code_key, project["starter_code"])

    code = st.text_area(
        "Build your project",
        value=code,
        height=300,
        key=code_key,
    )

    col1, col2 = st.columns(2)

    with col1:
        button(
            "Load Starter Code",
            f"starter_{pid}",
            lambda: rerun(**{code_key: project["starter_code"]}),
        )

    with col2:
        button(
            "Send to Review",
            f"review_{pid}",
            lambda: rerun(
                selected_mode="Review Mode",
                review_target_type="project",
                review_target_id=pid,
                review_target_code=code,
            ),
        )

    st.markdown("### Completion")

    if review_passed:
        st.success("Review passed. You can complete the project.")
    else:
        st.warning("Pass review before completing.")

    def complete_action(project_id: str) -> None:
        if mark_project_complete(project_id):
            st.success("Project completed.")
            st.rerun()
        else:
            st.error("Review must pass before completion.")

            button(
                "Mark Complete",
                f"complete_{pid}",
                lambda: complete_action(pid),
            )

    st.divider()

    button(
        "Back to Projects",
        f"back_{pid}",
        lambda: rerun(selected_project_id=None),
    )


# -------------------------
# MAIN RENDER
# -------------------------

def render(progress_data: Dict[str, Any]) -> None:

    _ = progress_data

    summary = project_summary()

    st.header("Project Mode")

    metric_row([
        ("Projects", summary["total"]),
        ("Review Passed", summary["review"]),
        ("Completed", summary["completed"]),
    ])

    selected = st.session_state.get("selected_project_id")

    if selected:
        project = get_project(selected)
        if project:
            render_project(project)
            return

    render_catalog()