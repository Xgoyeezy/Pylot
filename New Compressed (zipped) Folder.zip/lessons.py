from __future__ import annotations

from typing import Any, Dict, Iterable, List, Sequence

import streamlit as st

from progress import (
    get_learning_profile,
    has_passed_lesson_review,
    is_lesson_complete,
    mark_lesson_complete,
)


def build_lesson(
    lesson_id: str,
    title: str,
    level: str,
    duration: str,
    summary: str,
    concepts: Sequence[str],
    example_code: str,
    task: str,
    starter_code: str,
) -> Dict[str, Any]:
    return {
        "id": lesson_id,
        "title": title,
        "level": level,
        "duration": duration,
        "summary": summary,
        "concepts": list(concepts),
        "example_code": example_code,
        "task": task,
        "starter_code": starter_code,
    }


CURRICULUM: Dict[str, List[Dict[str, Any]]] = {
    "Beginner Track": [
        build_lesson(
            lesson_id="python-basics-1",
            title="Python Basics",
            level="Beginner",
            duration="15 min",
            summary="Learn what Python is, how code runs, and how to write your first simple statements.",
            concepts=[
                "What Python is",
                "Running Python code",
                "Using print()",
                "Reading simple statements",
            ],
            example_code='print("Hello, Pylot!")\nprint("Python is running.")',
            task="Write two print statements: one that prints your name, and one that prints your favorite hobby.",
            starter_code='print("Your name here")\nprint("Your hobby here")',
        ),
        build_lesson(
            lesson_id="variables-1",
            title="Variables",
            level="Beginner",
            duration="20 min",
            summary="Store values in variables and use them later in your code.",
            concepts=[
                "Creating variables",
                "String variables",
                "Number variables",
                "Printing variable values",
            ],
            example_code='name = "Marcus"\nage = 21\n\nprint(name)\nprint(age)',
            task="Create variables called name and favorite_number, then print both of them.",
            starter_code='name = ""\nfavorite_number = 0\n\nprint(name)\nprint(favorite_number)',
        ),
        build_lesson(
            lesson_id="conditionals-1",
            title="Conditionals",
            level="Beginner",
            duration="20 min",
            summary="Use if/else logic to make decisions in your programs.",
            concepts=[
                "if statements",
                "else statements",
                "Boolean conditions",
                "Branching program flow",
            ],
            example_code='number = 7\n\nif number > 0:\n    print("Positive")\nelse:\n    print("Not positive")',
            task="Create a variable called score. If score is 70 or higher, print Pass. Otherwise print Try again.",
            starter_code='score = 0\n\n# write your if/else here',
        ),
        build_lesson(
            lesson_id="loops-1",
            title="Loops",
            level="Beginner",
            duration="25 min",
            summary="Repeat actions with for loops and start thinking in patterns.",
            concepts=[
                "for loops",
                "Loop variables",
                "Repeating output",
                "Iterating over lists",
            ],
            example_code='numbers = [1, 2, 3]\n\nfor number in numbers:\n    print(number)',
            task="Create a list of three foods and use a for loop to print each one.",
            starter_code='foods = ["", "", ""]\n\nfor food in foods:\n    print(food)',
        ),
    ],
    "Intermediate Track": [
        build_lesson(
            lesson_id="functions-1",
            title="Functions",
            level="Intermediate",
            duration="25 min",
            summary="Create reusable blocks of logic with parameters and return values.",
            concepts=[
                "def statements",
                "Parameters",
                "Return values",
                "Function calls",
            ],
            example_code='def square(number):\n    return number * number\n\nprint(square(5))',
            task="Write a function called greet that takes a name and returns a greeting string.",
            starter_code='def greet(name):\n    # return a greeting\n    pass\n\nprint(greet("Marcus"))',
        ),
        build_lesson(
            lesson_id="lists-dicts-1",
            title="Lists and Dictionaries",
            level="Intermediate",
            duration="30 min",
            summary="Work with grouped data using Python collections.",
            concepts=[
                "Lists",
                "Dictionaries",
                "Indexing",
                "Key access",
            ],
            example_code='student = {"name": "Marcus", "score": 95}\nprint(student["name"])',
            task="Create a dictionary with keys name and city, then print both values.",
            starter_code='person = {"name": "", "city": ""}\n\nprint(person["name"])\nprint(person["city"])',
        ),
    ],
    "Advanced Track": [
        build_lesson(
            lesson_id="errors-testing-1",
            title="Errors and Testing",
            level="Advanced",
            duration="30 min",
            summary="Understand common errors and start thinking about validating behavior.",
            concepts=[
                "Exceptions",
                "try/except",
                "Testing behavior",
                "Failure cases",
            ],
            example_code='try:\n    number = int("abc")\nexcept ValueError:\n    print("That was not a valid number.")',
            task="Write code that catches a ValueError when converting bad input to int.",
            starter_code='try:\n    value = int("abc")\nexcept ValueError:\n    print("Invalid number")',
        ),
    ],
}


def render_header_panel(title: str, description: str, icon: str, track: str = "") -> None:
    track_html = ""
    if track:
        track_html = (
            f'<div style="font-size:0.9rem; color: rgb(100, 116, 139); margin-bottom:0.25rem;">'
            f"{track}</div>"
        )

    st.markdown(
        f"""
        <div style="
            padding: 1rem;
            border-radius: 18px;
            background: rgb(248, 250, 252);
            border: 1px solid rgba(148, 163, 184, 0.18);
            margin-bottom: 1rem;
        ">
            {track_html}
            <h3 style="margin:0;">{icon} {title}</h3>
            <p style="margin:0.35rem 0 0 0; color: rgb(71, 85, 105);">{description}</p>
        </div>
        """,
        unsafe_allow_html=True,
    )


def render_metrics(items: Sequence[tuple[str, Any]]) -> None:
    columns = st.columns(len(items))
    for column, (label, value) in zip(columns, items):
        with column:
            st.metric(label, value)


def render_bullet_section(title: str, items: Iterable[str]) -> None:
    st.markdown(f"### {title}")
    for item in items:
        st.write(f"- {item}")


def open_lesson(lesson_id: str) -> None:
    st.session_state["selected_lesson_id"] = lesson_id
    st.rerun()


def back_to_catalog() -> None:
    st.session_state["selected_lesson_id"] = None
    st.rerun()


def send_to_review(lesson_id: str, code: str) -> None:
    st.session_state["selected_mode"] = "Review Mode"
    st.session_state["review_target_type"] = "lesson"
    st.session_state["review_target_id"] = lesson_id
    st.session_state["review_target_code"] = code
    st.rerun()


def get_all_lessons() -> List[Dict[str, Any]]:
    all_lessons: List[Dict[str, Any]] = []
    for track_name, track_lessons in CURRICULUM.items():
        for lesson in track_lessons:
            lesson_copy = dict(lesson)
            lesson_copy["track"] = track_name
            all_lessons.append(lesson_copy)
    return all_lessons


def get_lesson_by_id(lesson_id: str) -> Dict[str, Any] | None:
    return next((lesson for lesson in get_all_lessons() if lesson["id"] == lesson_id), None)


def get_lesson_progress_summary() -> Dict[str, int]:
    lessons = get_all_lessons()
    completed_count = sum(1 for lesson in lessons if is_lesson_complete(lesson["id"]))
    passed_review_count = sum(1 for lesson in lessons if has_passed_lesson_review(lesson["id"]))

    return {
        "total": len(lessons),
        "completed": completed_count,
        "passed_review": passed_review_count,
    }


def render_learning_recommendation() -> None:
    profile = get_learning_profile()

    render_header_panel(
        title="Curriculum",
        description="Follow a structured path from beginner to advanced Python topics.",
        icon="📚",
    )

    st.info(
        f"Recommended next step: {profile['recommended_mode']} • "
        f"Focus topic: {profile['recommended_topic']}"
    )


def render_card_container(
    title: str,
    summary: str,
    track: str,
    meta_lines: Sequence[str],
    status_lines: Sequence[tuple[str, str, str]],
) -> None:
    meta_html = "<br>".join(meta_lines)
    status_html = "".join(
        f'<div style="font-size:{font_size}; color: {color};">{text}</div>'
        for text, font_size, color in status_lines
    )

    st.markdown(
        f"""
        <div style="
            border: 1px solid rgba(148, 163, 184, 0.20);
            border-radius: 18px;
            padding: 1rem;
            background: white;
            min-height: 210px;
        ">
            <div style="display:flex; justify-content:space-between; gap:1rem; align-items:flex-start;">
                <div>
                    <div style="font-size:0.85rem; color: rgb(100, 116, 139); margin-bottom:0.25rem;">{track}</div>
                    <h4 style="margin:0;">{title}</h4>
                    <p style="margin:0.3rem 0 0 0; color: rgb(71, 85, 105);">{summary}</p>
                </div>
                <div style="text-align:right; white-space:nowrap;">
                    {status_html}
                </div>
            </div>
            <div style="margin-top:0.8rem; color: rgb(71, 85, 105); font-size:0.92rem;">
                {meta_html}
            </div>
        </div>
        """,
        unsafe_allow_html=True,
    )


def render_catalog_card(lesson: Dict[str, Any]) -> None:
    lesson_id = lesson["id"]
    completed = is_lesson_complete(lesson_id)
    review_passed = has_passed_lesson_review(lesson_id)

    primary_status = "✅ Complete" if completed else "🟡 In Progress"
    secondary_status = "Review passed" if review_passed else "Review not passed"

    render_card_container(
        title=lesson["title"],
        summary=lesson["summary"],
        track=lesson["track"],
        meta_lines=[
            f"<strong>Level:</strong> {lesson['level']} &nbsp;&nbsp; <strong>Duration:</strong> {lesson['duration']}",
        ],
        status_lines=[
            (primary_status, "0.9rem", "rgb(51, 65, 85)"),
            (secondary_status, "0.85rem", "rgb(100, 116, 139)"),
        ],
    )

    if st.button(
        f"Open {lesson['title']}",
        key=f"open_lesson_{lesson_id}",
        use_container_width=True,
    ):
        open_lesson(lesson_id)


def render_track(track_name: str, track_lessons: Sequence[Dict[str, Any]]) -> None:
    st.subheader(track_name)

    left_column, right_column = st.columns(2)
    columns = [left_column, right_column]

    for index, lesson in enumerate(track_lessons):
        lesson_with_track = dict(lesson)
        lesson_with_track["track"] = track_name
        with columns[index % 2]:
            render_catalog_card(lesson_with_track)
            st.markdown("")


def render_lesson_editor(lesson: Dict[str, Any]) -> str:
    lesson_id = lesson["id"]
    state_key = f"lesson_code_{lesson_id}"
    widget_key = f"lesson_editor_{lesson_id}"

    current_code = st.session_state.get(state_key, lesson["starter_code"])
    updated_code = st.text_area(
        "Write your code here",
        value=current_code,
        height=260,
        key=widget_key,
    )
    st.session_state[state_key] = updated_code
    return updated_code


def render_editor_actions(lesson: Dict[str, Any], updated_code: str) -> None:
    lesson_id = lesson["id"]
    state_key = f"lesson_code_{lesson_id}"

    left_column, right_column = st.columns(2)

    with left_column:
        if st.button(
            "Load Starter Code",
            key=f"load_starter_{lesson_id}",
            use_container_width=True,
        ):
            st.session_state[state_key] = lesson["starter_code"]
            st.rerun()

    with right_column:
        if st.button(
            "Go to Review Mode",
            key=f"go_review_{lesson_id}",
            use_container_width=True,
        ):
            send_to_review(lesson_id, updated_code)


def render_completion_section(lesson_id: str) -> None:
    completed = is_lesson_complete(lesson_id)
    review_passed = has_passed_lesson_review(lesson_id)

    st.markdown("### Completion")

    if review_passed:
        st.success("Review passed. You can now mark this lesson complete.")
    else:
        st.warning("You must pass review before completing this lesson.")

    if st.button(
        "Mark Lesson Complete",
        key=f"mark_complete_{lesson_id}",
        use_container_width=True,
        disabled=(not review_passed) or completed,
    ):
        if mark_lesson_complete(lesson_id):
            st.success("Lesson marked complete.")
            st.rerun()
        else:
            st.error("Lesson cannot be completed until review is passed.")

    if completed:
        st.caption("This lesson is already complete.")

    if st.button("Back to All Lessons", key=f"back_to_lessons_{lesson_id}"):
        back_to_catalog()


def render_detail_header(lesson: Dict[str, Any]) -> None:
    completed = is_lesson_complete(lesson["id"])

    render_header_panel(
        title=lesson["title"],
        description=lesson["summary"],
        icon="📘",
        track=lesson["track"],
    )

    render_metrics(
        [
            ("Level", lesson["level"]),
            ("Duration", lesson["duration"]),
            ("Status", "Complete" if completed else "Active"),
        ]
    )


def render_lesson_content_sections(lesson: Dict[str, Any]) -> None:
    render_bullet_section("Concepts", lesson["concepts"])

    st.markdown("### Worked Example")
    st.code(lesson["example_code"], language="python")

    st.markdown("### Your Task")
    st.info(lesson["task"])


def render_lesson_detail(lesson: Dict[str, Any]) -> None:
    render_detail_header(lesson)
    render_lesson_content_sections(lesson)

    updated_code = render_lesson_editor(lesson)
    render_editor_actions(lesson, updated_code)
    render_completion_section(lesson["id"])


def render_catalog() -> None:
    for track_name, track_lessons in CURRICULUM.items():
        render_track(track_name, track_lessons)


def render(progress_data: Dict[str, Any]) -> None:
    _ = progress_data

    summary = get_lesson_progress_summary()
    render_learning_recommendation()

    render_metrics(
        [
            ("Lessons", summary["total"]),
            ("Review Passed", summary["passed_review"]),
            ("Completed", summary["completed"]),
        ]
    )

    selected_lesson_id = st.session_state.get("selected_lesson_id")
    selected_lesson = get_lesson_by_id(selected_lesson_id) if selected_lesson_id else None

    if selected_lesson is not None:
        render_lesson_detail(selected_lesson)
        return

    render_catalog()