from __future__ import annotations

from typing import Any, Callable, Dict, Tuple

import streamlit as st

import lessons
from core import ai, debug, explain, file_analyzer, memory, practice, project, review, run_project
from progress import get_learning_profile, init_progress_db, load_progress


APP_TITLE = "Pylot"
APP_ICON = "🐍"

MODE_LABELS: Tuple[str, ...] = (
    "Home",
    "Course Mode",
    "Practice Mode",
    "Project Mode",
    "Run/Test Mode",
    "AI Mode",
    "Debug Mode",
    "Explain Mode",
    "Review Mode",
    "File Analyzer Mode",
    "Shared Memory Admin",
)

MODE_RENDERERS: Dict[str, Callable[[Dict[str, Any]], None]] = {
    "Course Mode": lessons.render,
    "Practice Mode": practice.render,
    "Project Mode": project.render,
    "Run/Test Mode": run_project.render,
    "AI Mode": ai.render,
    "Debug Mode": debug.render,
    "Explain Mode": explain.render,
    "Review Mode": review.render,
    "File Analyzer Mode": file_analyzer.render,
    "Shared Memory Admin": memory.render,
}


def configure_page() -> None:
    st.set_page_config(
        page_title=APP_TITLE,
        page_icon=APP_ICON,
        layout="wide",
        initial_sidebar_state="expanded",
    )


def inject_global_styles() -> None:
    st.markdown(
        """
        <style>
        .block-container {
            padding-top: 1.2rem;
            padding-bottom: 2rem;
        }

        div[data-testid="stSidebar"] {
            border-right: 1px solid rgba(148, 163, 184, 0.18);
        }

        .pylot-shell-card {
            padding: 1rem;
            border-radius: 18px;
            background: rgb(248, 250, 252);
            border: 1px solid rgba(148, 163, 184, 0.18);
            margin-bottom: 1rem;
        }

        .pylot-shell-card h1,
        .pylot-shell-card h2,
        .pylot-shell-card h3,
        .pylot-shell-card h4,
        .pylot-shell-card p {
            margin-top: 0;
            margin-bottom: 0;
        }

        .pylot-muted {
            color: rgb(71, 85, 105);
        }
        </style>
        """,
        unsafe_allow_html=True,
    )


def ensure_app_state() -> Dict[str, Any]:
    init_progress_db()

    if "selected_mode" not in st.session_state:
        st.session_state["selected_mode"] = "Home"

    if "selected_lesson_id" not in st.session_state:
        st.session_state["selected_lesson_id"] = None

    if "selected_project_id" not in st.session_state:
        st.session_state["selected_project_id"] = None

    if "review_target_type" not in st.session_state:
        st.session_state["review_target_type"] = None

    if "review_target_id" not in st.session_state:
        st.session_state["review_target_id"] = None

    if "review_target_code" not in st.session_state:
        st.session_state["review_target_code"] = ""

    progress_data = load_progress()
    st.session_state["progress_data"] = progress_data
    return progress_data


def init_auth_safely() -> tuple[bool, str]:
    try:
        from core.auth import init_auth

        init_auth()
        return True, ""
    except ImportError:
        return False, "Authentication module is unavailable. Running in guest mode."
    except AttributeError:
        return False, "Authentication is partially configured. Running in guest mode."
    except RuntimeError:
        return False, "Authentication is not configured. Running in guest mode."


def render_auth_sidebar() -> None:
    try:
        from core.auth import account_badge, auth_sidebar

        auth_sidebar()
        account_badge()
    except ImportError:
        st.markdown("### Account")
        st.info("Guest mode is active.")
        st.caption("Authentication module is unavailable.")
    except AttributeError:
        st.markdown("### Account")
        st.info("Guest mode is active.")
        st.caption("Authentication UI is unavailable.")
    except RuntimeError:
        st.markdown("### Account")
        st.info("Guest mode is active.")
        st.caption("Authentication is not configured.")


def render_shell_header(mode: str) -> None:
    st.markdown(
        f"""
        <div class="pylot-shell-card">
            <h2>{APP_ICON} {APP_TITLE}</h2>
            <p class="pylot-muted" style="margin-top:0.35rem;">
                Interactive Python learning with lessons, practice, projects, AI tutoring,
                debugging tools, code review, and progress tracking.
            </p>
            <p class="pylot-muted" style="margin-top:0.45rem;">
                Current mode: <strong>{mode}</strong>
            </p>
        </div>
        """,
        unsafe_allow_html=True,
    )


def render_sidebar(progress_data: Dict[str, Any]) -> None:
    profile = get_learning_profile()

    with st.sidebar:
        st.markdown("## Navigation")

        selected_mode = st.radio(
            "Choose a mode",
            options=MODE_LABELS,
            index=MODE_LABELS.index(st.session_state.get("selected_mode", "Home")),
            key="selected_mode",
            label_visibility="collapsed",
        )

        st.markdown("---")
        st.markdown("### Learning Profile")

        col1, col2 = st.columns(2)
        with col1:
            st.metric("Lessons", profile["completed_lessons"])
        with col2:
            st.metric("Projects", profile["completed_projects"])

        st.caption(f"Recommended mode: {profile['recommended_mode']}")
        st.caption(f"Focus topic: {profile['recommended_topic']}")

        top_weak_topics = profile.get("top_weak_topics", [])
        if top_weak_topics:
            st.markdown("### Weak Topics")
            for topic, score in top_weak_topics:
                st.write(f"- {topic} ({score})")
        else:
            st.caption("No major weak topics detected yet.")

        st.markdown("---")
        render_auth_sidebar()

        st.markdown("---")
        if st.button("Return to Home", use_container_width=True):
            clear_detail_navigation()
            st.session_state["selected_mode"] = "Home"
            st.rerun()

    st.session_state["progress_data"] = progress_data
    st.session_state["selected_mode"] = selected_mode


def clear_detail_navigation() -> None:
    st.session_state["selected_lesson_id"] = None
    st.session_state["selected_project_id"] = None


def navigate_to(mode: str) -> None:
    st.session_state["selected_mode"] = mode
    st.rerun()


def render_home_hero(profile: Dict[str, Any]) -> None:
    st.markdown(
        """
        <div class="pylot-shell-card">
            <h3>Learn Python like a product, not a worksheet</h3>
            <p class="pylot-muted" style="margin-top:0.4rem;">
                Move through structured lessons, reinforce weak topics with adaptive practice,
                complete milestone projects, test code, and get help from the AI tutor.
            </p>
        </div>
        """,
        unsafe_allow_html=True,
    )

    col1, col2, col3 = st.columns(3)
    with col1:
        st.metric("Completed Lessons", profile["completed_lessons"])
    with col2:
        st.metric("Completed Projects", profile["completed_projects"])
    with col3:
        st.metric("Review Passes", profile["review_passed_count"])


def render_home_recommendation(profile: Dict[str, Any]) -> None:
    st.markdown("### Recommended Next Step")
    st.info(
        f"Mode: {profile['recommended_mode']} • Topic: {profile['recommended_topic']}"
    )

    col1, col2 = st.columns([2, 1])
    with col1:
        st.write(
            "Pylot uses your progress and weak topics to guide you toward the next best activity."
        )
    with col2:
        if st.button("Open Recommended Mode", use_container_width=True):
            clear_detail_navigation()
            navigate_to(profile["recommended_mode"])


def render_home_mode_cards() -> None:
    st.markdown("### Explore Modes")

    mode_descriptions = [
        ("Course Mode", "Follow structured lessons across beginner, intermediate, and advanced topics."),
        ("Practice Mode", "Get targeted exercises based on weak topics and recent review results."),
        ("Project Mode", "Build milestone-based Python projects and unlock completion through review."),
        ("Run/Test Mode", "Validate syntax and run Python code directly inside the app."),
        ("AI Mode", "Ask natural Python questions, debug code, and request examples or exercises."),
        ("Debug Mode", "Paste broken code and tracebacks to get structured debugging help."),
        ("Explain Mode", "Get concept or code explanations."),
        ("Review Mode", "Run completion-gating code review for lessons and projects."),
        ("File Analyzer Mode", "Upload Python files and inspect imports, functions, classes, and issues."),
        ("Shared Memory Admin", "Inspect and manage shared AI memory entries."),
    ]

    col1, col2 = st.columns(2)
    columns = [col1, col2]

    for index, (mode_name, description) in enumerate(mode_descriptions):
        with columns[index % 2]:
            st.markdown(
                f"""
                <div style="
                    border: 1px solid rgba(148, 163, 184, 0.20);
                    border-radius: 18px;
                    padding: 1rem;
                    background: white;
                    min-height: 150px;
                    margin-bottom: 0.75rem;
                ">
                    <h4 style="margin:0;">{mode_name}</h4>
                    <p style="margin:0.4rem 0 0 0; color: rgb(71, 85, 105);">
                        {description}
                    </p>
                </div>
                """,
                unsafe_allow_html=True,
            )
            if st.button(f"Open {mode_name}", key=f"home_open_{mode_name}", use_container_width=True):
                clear_detail_navigation()
                navigate_to(mode_name)


def render_home(progress_data: Dict[str, Any]) -> None:
    _ = progress_data
    profile = get_learning_profile()

    render_home_hero(profile)
    render_home_recommendation(profile)
    render_home_mode_cards()


def render_selected_mode(progress_data: Dict[str, Any]) -> None:
    selected_mode = st.session_state.get("selected_mode", "Home")

    if selected_mode == "Home":
        render_home(progress_data)
        return

    renderer = MODE_RENDERERS.get(selected_mode)
    if renderer is None:
        st.error(f"Unknown mode: {selected_mode}")
        return

    renderer(progress_data)


def main() -> None:
    configure_page()
    inject_global_styles()

    auth_ok, auth_message = init_auth_safely()
    progress_data = ensure_app_state()

    render_sidebar(progress_data)
    render_shell_header(st.session_state.get("selected_mode", "Home"))

    if not auth_ok and auth_message:
        st.caption(auth_message)

    render_selected_mode(progress_data)


if __name__ == "__main__":
    main()